/**
 * Distributed transaction and delivery-guarantee semantic decorators.
 *
 * These describe saga, outbox, inbox, and checkpoint semantics without
 * requiring a specific workflow engine or message broker.
 */

import { defineDecorator } from '../core/define'
import { registerMetadata } from '../core/registry'
import type { TDecoratorFunction } from '../core/types'

// ── tSaga ──────────────────────────────────────────────────────────────

export interface TSagaOptions {
  version?: string
  timeout?: number
}

export const tSaga = (name: string, options: TSagaOptions = {}): TDecoratorFunction =>
  defineDecorator(
    {
      name: 'tSaga',
      description: 'Declares a class as a distributed saga',
      purpose: 'Marks a class as an orchestrated distributed workflow',
      why: 'Distributed transactions require explicit workflow semantics',
      whenToUse: 'On workflow classes coordinating multiple services',
      category: 'Distributed',
      targets: ['class'],
      consumedBy: ['Workflow Engine'],
      composesWith: ['tStep', 'tCompensate'],
      examples: ['@tSaga("checkout")']
    },
    (target) => {
      registerMetadata('tSaga', target, undefined, { name, ...options })
    }
  )

// ── tStep ──────────────────────────────────────────────────────────────

export interface TStepOptions {
  order?: number
}

export const tStep = (name: string, options: TStepOptions = {}): TDecoratorFunction =>
  defineDecorator(
    {
      name: 'tStep',
      description: 'Declares a workflow or saga step',
      purpose: 'Marks a method as an ordered step in a workflow or saga',
      why: 'Workflow steps are the fundamental unit of distributed execution',
      whenToUse: 'On methods belonging to a saga or workflow',
      category: 'Distributed',
      targets: ['method'],
      consumedBy: ['Workflow Engine'],
      composesWith: ['tSaga', 'tWorkflow', 'tCompensate', 'tCheckpoint'],
      examples: ['@tStep("reserve-inventory")', '@tStep("charge-payment", { order: 2 })']
    },
    (target, propertyKey) => {
      registerMetadata('tStep', target, propertyKey, { name, ...options })
    }
  )

// ── tCompensate ────────────────────────────────────────────────────────

export const tCompensate = (step: string): TDecoratorFunction =>
  defineDecorator(
    {
      name: 'tCompensate',
      description: 'Declares a compensating action for a workflow step',
      purpose: 'Executes when the referenced step must be rolled back',
      why: 'Compensation is essential for correctness in distributed workflows',
      whenToUse: 'On methods that reverse the effect of a completed step',
      category: 'Distributed',
      targets: ['method'],
      consumedBy: ['Workflow Engine'],
      composesWith: ['tSaga', 'tStep', 'tWorkflow'],
      examples: ['@tCompensate("charge-payment")']
    },
    (target, propertyKey) => {
      registerMetadata('tCompensate', target, propertyKey, { step })
    }
  )

// ── tOutbox ────────────────────────────────────────────────────────────

export interface TOutboxOptions {
  channel?: string
}

export const tOutbox = (options: TOutboxOptions = {}): TDecoratorFunction =>
  defineDecorator(
    {
      name: 'tOutbox',
      description: 'Transactional outbox event publication',
      purpose: 'Persists events atomically with the database transaction',
      why: 'The outbox pattern guarantees at-least-once event delivery',
      whenToUse: 'On operations that must publish events reliably',
      category: 'Distributed',
      targets: ['method'],
      consumedBy: ['Outbox Consumer', '@axiljs/events'],
      composesWith: ['tTransaction', 'tEmit'],
      examples: ['@tOutbox()', '@tOutbox({ channel: "domain-events" })']
    },
    (target, propertyKey) => {
      registerMetadata('tOutbox', target, propertyKey, options)
    }
  )

// ── tInbox ─────────────────────────────────────────────────────────────

export interface TInboxOptions {
  key?: string
  ttl?: number
}

export const tInbox = (options: TInboxOptions = {}): TDecoratorFunction =>
  defineDecorator(
    {
      name: 'tInbox',
      description: 'Idempotent event consumption via an inbox table',
      purpose: 'Guarantees at-most-once handling of received events',
      why: 'The inbox pattern complements the outbox for exactly-once semantics',
      whenToUse: 'On event handlers that must not process duplicates',
      category: 'Distributed',
      targets: ['method'],
      consumedBy: ['Inbox Consumer', '@axiljs/events'],
      composesWith: ['tOnEvent', 'tTransaction'],
      examples: ['@tInbox()']
    },
    (target, propertyKey) => {
      registerMetadata('tInbox', target, propertyKey, options)
    }
  )

// ── tCheckpoint ────────────────────────────────────────────────────────

export const tCheckpoint = (name: string): TDecoratorFunction =>
  defineDecorator(
    {
      name: 'tCheckpoint',
      description: 'Declares a resumable checkpoint in a workflow',
      purpose: 'Allows a workflow to resume from this point on failure',
      why: 'Checkpoints avoid re-running expensive completed work',
      whenToUse: 'On expensive workflow steps that should not be repeated',
      category: 'Distributed',
      targets: ['method'],
      consumedBy: ['Workflow Engine'],
      composesWith: ['tWorkflow', 'tStep'],
      examples: ['@tCheckpoint("after-index")']
    },
    (target, propertyKey) => {
      registerMetadata('tCheckpoint', target, propertyKey, { name })
    }
  )
